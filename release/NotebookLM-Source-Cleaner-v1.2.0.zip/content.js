/**
 * NotebookLM Source Cleaner — Content Script (v4 · Lean & Robust)
 * Manifest V3 | target: https://notebooklm.google.com/*
 *
 * Security: Trusted Types compliant — zero .innerHTML usage.
 * Design:   First-principles — exact selectors only, no heuristics.
 */

'use strict';

/* ── Selectors ─────────────────────────────────────────────────────────── */

const SELECTORS = {
  SIDEBAR:          'section.source-panel',
  SOURCE_ITEM:      '.single-source-container',
  MENU_BTN:         'button.source-item-more-button',
  DELETE_MENU_ITEM: 'button.more-menu-delete-source-button',
  ADD_SOURCE_AREA:  'button.add-source-button',
};

const LOCALES = {
  en: {
    preparing: 'Preparing...',
    cleaningProgress: 'Cleaning... ({current}/{total})',
    selectedCount: 'Selected {count}',
    exitBulk: 'Exit Bulk',
    bulkSelect: 'Bulk Select',
    deleteSelected: 'Delete Selected',
    successDeleted: 'Success: deleted {count} items',
    confirmDeleteTokens: ['delete'],
  },
  'zh-CN': {
    preparing: '准备中...',
    cleaningProgress: '正在清理... ({current}/{total})',
    selectedCount: '已选 {count} 项',
    exitBulk: '退出批量',
    bulkSelect: '批量选择',
    deleteSelected: '删除选中',
    successDeleted: '成功删除 {count} 条',
    confirmDeleteTokens: ['删除', 'delete'],
  },
  'zh-TW': {
    preparing: '準備中...',
    cleaningProgress: '正在清理... ({current}/{total})',
    selectedCount: '已選 {count} 項',
    exitBulk: '退出批次',
    bulkSelect: '批次選擇',
    deleteSelected: '刪除選中',
    successDeleted: '成功刪除 {count} 筆',
    confirmDeleteTokens: ['刪除', '删除', 'delete'],
  },
  ja: {
    preparing: '準備中...',
    cleaningProgress: '削除中... ({current}/{total})',
    selectedCount: '{count} 件を選択',
    exitBulk: '一括選択を終了',
    bulkSelect: '一括選択',
    deleteSelected: '選択を削除',
    successDeleted: '{count} 件を削除しました',
    confirmDeleteTokens: ['削除', 'delete'],
  },
  es: {
    preparing: 'Preparando...',
    cleaningProgress: 'Limpiando... ({current}/{total})',
    selectedCount: '{count} seleccionados',
    exitBulk: 'Salir del modo masivo',
    bulkSelect: 'Seleccion masiva',
    deleteSelected: 'Eliminar seleccionados',
    successDeleted: 'Eliminados {count} elementos',
    confirmDeleteTokens: ['eliminar', 'delete'],
  },
};

function detectLocale() {
  const preferred = [...(navigator.languages || []), navigator.language, 'en'].filter(Boolean);
  for (const raw of preferred) {
    const normalized = String(raw).trim();
    if (LOCALES[normalized]) return normalized;
    const base = normalized.split('-')[0];
    if (LOCALES[base]) return base;
    if (base === 'zh') return 'zh-CN';
  }
  return 'en';
}

const ACTIVE_LOCALE = detectLocale();

function t(key, params) {
  const dict = LOCALES[ACTIVE_LOCALE] || LOCALES.en;
  const fallback = LOCALES.en;
  let template = dict[key] ?? fallback[key] ?? key;
  if (params && typeof template === 'string') {
    Object.entries(params).forEach(([k, v]) => {
      template = template.replace(new RegExp('\\{' + k + '\\}', 'g'), String(v));
    });
  }
  return template;
}

function getDeleteTokens() {
  const dict = LOCALES[ACTIVE_LOCALE] || LOCALES.en;
  const tokenList = Array.isArray(dict.confirmDeleteTokens) ? dict.confirmDeleteTokens : [];
  return new Set(
    [...tokenList, ...LOCALES.en.confirmDeleteTokens]
      .map((token) => token.replace(/\s+/g, '').toLowerCase())
  );
}

const CONFIRM_DELETE_TOKENS = getDeleteTokens();

const FAILURE_TYPES = {
  EVENT_CONFLICT: 'EVENT_CONFLICT',
  SELECTOR_MISS: 'SELECTOR_MISS',
  DIALOG_TIMEOUT: 'DIALOG_TIMEOUT',
  ROUTE_REMOUNT_FAIL: 'ROUTE_REMOUNT_FAIL',
};

const DIAG = {
  debugEnabled: false,
  failures: [],
  eventInterceptions: {
    pointerdown: 0,
    mousedown: 0,
    mouseup: 0,
    click: 0,
  },
};

function recordFailure(type, message, extra) {
  const entry = {
    ts: new Date().toISOString(),
    type,
    message,
    extra: extra || null,
  };
  DIAG.failures.push(entry);
  if (DIAG.failures.length > 50) {
    DIAG.failures.shift();
  }
  if (DIAG.debugEnabled) {
    console.warn('[NLM Cleaner][Failure]', entry);
  }
}

/* ── Utilities ─────────────────────────────────────────────────────────── */

function getSidebar() {
  return document.querySelector(SELECTORS.SIDEBAR);
}

function showToast(msg, duration = 2500) {
  const existing = document.querySelector('.nlm-processing-toast');
  if (existing) existing.remove();
  const toast = document.createElement('div');
  toast.className = 'nlm-processing-toast';
  toast.textContent = msg;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), duration);
}

/** Polls queryFn every 100 ms until it returns a truthy value or timeout. */
function waitForElement(queryFn, timeout = 3000) {
  return new Promise((resolve, reject) => {
    const deadline = Date.now() + timeout;
    const tick = () => {
      const el = queryFn();
      if (el) return resolve(el);
      if (Date.now() >= deadline) return reject(new Error('waitForElement timeout'));
      setTimeout(tick, 100);
    };
    tick();
  });
}

/** Dispatch mousedown + mouseup + click on an element. */
function simulateClick(el) {
  ['mousedown', 'mouseup', 'click'].forEach(type =>
    el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }))
  );
}

/**
 * Non-blocking async search for the Angular confirm-dialog "delete" button.
 * Scoped strictly to CDK / dialog overlay containers — never matches our own
 * toolbar buttons (which also contain "\u5220\u9664").
 * Each iteration yields the main thread via await — no busy-wait, no deadlock.
 */
async function confirmDeleteDialog() {
  const maxRetries = 30; // 3000ms 轮询上限
  const pollInterval = 100;

  for (let i = 0; i < maxRetries; i++) {
    // 定位 Angular 弹窗的各种潜在父级容器
    const overlayContainers = document.querySelectorAll(
      '.cdk-overlay-container, .cdk-global-overlay-wrapper, dialog, .mat-mdc-dialog-container'
    );

    for (const container of overlayContainers) {
      const buttons = container.querySelectorAll('button');
      for (const btn of buttons) {
        // 清洗文本：去除所有空白字符（换行、制表符、空格）
        const cleanText = btn.textContent.replace(/\s+/g, '').toLowerCase();

        if (CONFIRM_DELETE_TOKENS.has(cleanText)) {
          // 执行点击
          btn.click();
          if (typeof simulateClick === 'function') {
            simulateClick(btn);
          }

          // 状态断言：阻塞等待直到弹窗按钮从 DOM 树中彻底销毁
          let waitUnmountCount = 0;
          while (document.body.contains(btn) && waitUnmountCount < 10) {
            await new Promise(resolve => setTimeout(resolve, 100));
            waitUnmountCount++;
          }
          return true;
        }
      }
    }
    // 释放主线程
    await new Promise(resolve => setTimeout(resolve, pollInterval));
  }

  recordFailure(
    FAILURE_TYPES.DIALOG_TIMEOUT,
    '确认按钮查找超时',
    { pollInterval, maxRetries }
  );
  console.warn('[NLM Cleaner] 确认按钮查找超时。');
  return false;
}

/* ── Loading Overlay (full-screen, mounted on body) ───────────────────── */

let loadingOverlay = null;
let overlayProgressEl = null;

function mountLoadingOverlay(total) {
  dismissLoadingOverlay();

  const overlay = document.createElement('div');
  overlay.className = 'nlm-loading-overlay';

  const spinner = document.createElement('div');
  spinner.className = 'nlm-loading-spinner';
  overlay.appendChild(spinner);

  const progress = document.createElement('div');
  progress.className = 'nlm-loading-progress';
  progress.textContent = t('preparing');
  overlay.appendChild(progress);

  overlayProgressEl = progress;
  loadingOverlay = overlay;
  document.body.appendChild(overlay);
  requestAnimationFrame(() => updateOverlayProgress(0, total));
}

function updateOverlayProgress(current, total) {
  if (overlayProgressEl) {
    overlayProgressEl.textContent = t('cleaningProgress', { current, total });
  }
}

function dismissLoadingOverlay() {
  if (loadingOverlay) {
    loadingOverlay.remove();
    loadingOverlay = null;
    overlayProgressEl = null;
  }
}

/* ── Core Delete Flow ──────────────────────────────────────────────────── */

async function deleteSourceItem(sourceItem) {
  // Step 1: exact selector only — no heuristic fallbacks
  const menuBtn = sourceItem.querySelector(SELECTORS.MENU_BTN);
  if (!menuBtn) {
    recordFailure(
      FAILURE_TYPES.SELECTOR_MISS,
      '未找到来源菜单按钮',
      { selector: SELECTORS.MENU_BTN }
    );
    console.warn('[NLM Cleaner] Menu button not found:', SELECTORS.MENU_BTN);
    return false;
  }

  // Step 2: open popup menu
  simulateClick(menuBtn);

  // Step 3: wait for delete menu item
  let deleteMenuItem;
  try {
    deleteMenuItem = await waitForElement(
      () => document.querySelector(SELECTORS.DELETE_MENU_ITEM),
      3000
    );
  } catch (e) {
    recordFailure(
      FAILURE_TYPES.SELECTOR_MISS,
      '未找到删除菜单项',
      { selector: SELECTORS.DELETE_MENU_ITEM }
    );
    console.warn('[NLM Cleaner] Delete menu item not found — pressing Escape');
    document.dispatchEvent(
      new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true })
    );
    return false;
  }

  // Step 4: click delete menu item
  simulateClick(deleteMenuItem);

  // Step 5: non-blocking confirm dialog (scoped to overlay containers)
  await confirmDeleteDialog();

  return true;
}

/* ── Bulk Delete ───────────────────────────────────────────────────────── */

let isBulkMode = false;
let bulkToolbar = null;
let selectedCount = 0;

function getAllSourceItems() {
  const sidebar = getSidebar();
  if (!sidebar) {
    console.warn('[NLM Cleaner] Sidebar not found — source items unavailable');
    return [];
  }
  return [...sidebar.querySelectorAll(SELECTORS.SOURCE_ITEM)];
}

function updateBulkUI() {
  const deleteBtn = document.getElementById('nlm-bulk-delete-btn');
  const countLabel = document.getElementById('nlm-selected-count');
  if (!deleteBtn || !countLabel) return;
  const checked = document.querySelectorAll('.nlm-source-checkbox:checked');
  selectedCount = checked.length;
  countLabel.textContent =
    selectedCount > 0 ? t('selectedCount', { count: selectedCount }) : '';
  deleteBtn.disabled = selectedCount === 0;
}

function injectCheckbox(sourceItem) {
  if (sourceItem.querySelector('.nlm-source-checkbox')) return;
  const cb = document.createElement('input');
  cb.type = 'checkbox';
  cb.className = 'nlm-source-checkbox';

  // 仅阻断冒泡，不阻止默认勾选行为
  cb.addEventListener('click', (event) => {
    event.stopPropagation();
  });

  // 兜底拦截早于 click 的链路，避免宿主页在 down 阶段触发详情跳转
  ['pointerdown', 'mousedown', 'mouseup'].forEach((type) => {
    cb.addEventListener(type, (event) => {
      event.stopPropagation();
    });
  });

  // 保持原有的change事件监听器
  cb.addEventListener('change', updateBulkUI);

  sourceItem.insertBefore(cb, sourceItem.firstChild);
}

function removeAllCheckboxes() {
  document.querySelectorAll('.nlm-source-checkbox').forEach(cb => cb.remove());
}

function toggleBulkMode() {
  isBulkMode = !isBulkMode;
  const toggleBtn = document.getElementById('nlm-bulk-toggle-btn');
  const deleteBtn  = document.getElementById('nlm-bulk-delete-btn');
  const countLabel = document.getElementById('nlm-selected-count');

  if (isBulkMode) {
    getAllSourceItems().forEach(injectCheckbox);
    toggleBtn?.classList.add('active');
    if (toggleBtn) {
      toggleBtn.textContent = '';
      toggleBtn.appendChild(createMaterialIcon('close'));
      toggleBtn.appendChild(document.createTextNode(t('exitBulk')));
    }
    if (deleteBtn) deleteBtn.style.display = 'inline-flex';
    if (countLabel) countLabel.style.display = 'inline';
    updateBulkUI();
  } else {
    removeAllCheckboxes();
    toggleBtn?.classList.remove('active');
    if (toggleBtn) {
      toggleBtn.textContent = '';
      toggleBtn.appendChild(createMaterialIcon('checklist'));
      toggleBtn.appendChild(document.createTextNode(t('bulkSelect')));
    }
    if (deleteBtn) deleteBtn.style.display = 'none';
    if (countLabel) countLabel.style.display = 'none';
    selectedCount = 0;
  }
}

async function executeBulkDelete() {
  const checkedBoxes = [...document.querySelectorAll('.nlm-source-checkbox:checked')];
  if (checkedBoxes.length === 0) return;

  const deleteBtn = document.getElementById('nlm-bulk-delete-btn');
  const toggleBtn = document.getElementById('nlm-bulk-toggle-btn');
  if (deleteBtn) deleteBtn.disabled = true;
  if (toggleBtn) toggleBtn.disabled = true;

  document.body.classList.add('nlm-is-deleting');
  mountLoadingOverlay(checkedBoxes.length);

  let successCount = 0;
  try {
    let i = 0;
    for (const checkbox of checkedBoxes) {
      updateOverlayProgress(++i, checkedBoxes.length);
      const sourceItem = checkbox.closest(SELECTORS.SOURCE_ITEM) || checkbox.parentElement;
      if (!sourceItem) continue;
      try {
        const ok = await deleteSourceItem(sourceItem);
        if (ok) successCount++;
      } catch (err) {
        console.warn('[NLM Cleaner] Item failed, skipping:', err);
      }
    }
  } finally {
    // Guaranteed cleanup — page will never stay permanently blocked
    document.body.classList.remove('nlm-is-deleting');
    dismissLoadingOverlay();
    showToast(t('successDeleted', { count: successCount }), 2500);
    if (isBulkMode) toggleBulkMode();
    if (toggleBtn) toggleBtn.disabled = false;
  }
}

/* ── Material Icon Helper ──────────────────────────────────────────────── */

/** Safely create a Material Symbols icon span (no innerHTML). */
function createMaterialIcon(iconName) {
  const icon = document.createElement('span');
  icon.className = 'google-symbols';
  icon.textContent = iconName;
  icon.style.fontSize = '18px';
  icon.style.marginRight = '6px';
  icon.style.verticalAlign = 'middle';
  return icon;
}

/* ── Bulk Toolbar ──────────────────────────────────────────────────────── */

function createToolbarDOM() {
  const toolbar = document.createElement('div');
  toolbar.id = 'nlm-bulk-toolbar';

  const toggleBtn = document.createElement('button');
  toggleBtn.id = 'nlm-bulk-toggle-btn';
  toggleBtn.style.display = 'inline-flex';
  toggleBtn.style.alignItems = 'center';
  toggleBtn.appendChild(createMaterialIcon('checklist'));
  toggleBtn.appendChild(document.createTextNode(t('bulkSelect')));
  toggleBtn.addEventListener('click', toggleBulkMode);

  const countLabel = document.createElement('span');
  countLabel.id = 'nlm-selected-count';
  countLabel.style.display = 'none';

  const deleteBtn = document.createElement('button');
  deleteBtn.id = 'nlm-bulk-delete-btn';
  deleteBtn.style.display = 'none';
  deleteBtn.style.alignItems = 'center';
  deleteBtn.disabled = true;
  deleteBtn.appendChild(createMaterialIcon('delete'));
  deleteBtn.appendChild(document.createTextNode(t('deleteSelected')));
  deleteBtn.addEventListener('click', executeBulkDelete);

  toolbar.appendChild(toggleBtn);
  toolbar.appendChild(countLabel);
  toolbar.appendChild(deleteBtn);

  bulkToolbar = toolbar;
  return toolbar;
}

function injectBulkToolbar() {
  if (document.getElementById('nlm-bulk-toolbar')) return;
  const sidebar = getSidebar();
  if (!sidebar) {
    recordFailure(
      FAILURE_TYPES.SELECTOR_MISS,
      '工具栏注入失败：未找到侧边栏',
      { selector: SELECTORS.SIDEBAR }
    );
    console.warn('[NLM Cleaner] Toolbar injection failed: sidebar not found');
    return;
  }
  const addSourceBtn = sidebar.querySelector(SELECTORS.ADD_SOURCE_AREA);
  if (addSourceBtn) {
    // 优先定位原生 .button-row 包裹层，确保工具栏继承相同的水平内边距和对齐上下文
    const buttonRow = addSourceBtn.closest('.button-row') || addSourceBtn.parentElement || addSourceBtn;
    buttonRow.insertAdjacentElement('afterend', createToolbarDOM());
    return;
  }
  // 备用：找不到按鈕时，插入至侧边栏首子节点之前
  sidebar.insertBefore(createToolbarDOM(), sidebar.firstChild);
}

/* ── Scan & Inject ─────────────────────────────────────────────────────── */

function scanAndInject() {
  getAllSourceItems().forEach(item => {
    if (isBulkMode) injectCheckbox(item);
  });
  injectBulkToolbar();
}

/* ── Lifecycle ─────────────────────────────────────────────────────────── */

let currentUrl = location.href;
let isPluginMounted = false;
let innerObserver = null;
let mountDebounceTimer = null;
let scanDebounceTimer = null;

function isNotebookUrl(url) {
  return url.includes('/notebook/');
}

function debouncedScan(delay = 250) {
  clearTimeout(scanDebounceTimer);
  scanDebounceTimer = setTimeout(scanAndInject, delay);
}

function startInnerObserver(listContainer) {
  if (innerObserver) { innerObserver.disconnect(); innerObserver = null; }

  innerObserver = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== 'childList') continue;
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== Node.ELEMENT_NODE) continue;
        if (node.matches?.(SELECTORS.SOURCE_ITEM)) {
          if (isBulkMode) injectCheckbox(node);
        } else if (node.querySelectorAll?.(SELECTORS.SOURCE_ITEM).length > 0) {
          debouncedScan(100);
          break;
        }
      }
    }
  });

  innerObserver.observe(listContainer, { childList: true, subtree: true });
  console.log('[NLM Cleaner] Inner Observer started');
}

function teardown() {
  innerObserver?.disconnect();
  innerObserver = null;
  clearTimeout(mountDebounceTimer);
  clearTimeout(scanDebounceTimer);
  document.getElementById('nlm-bulk-toolbar')?.remove();
  dismissLoadingOverlay();
  document.body.classList.remove('nlm-is-deleting');
  isBulkMode = false;
  selectedCount = 0;
  bulkToolbar = null;
  isPluginMounted = false;
  console.log('[NLM Cleaner] Teardown complete');
}

async function attemptMount() {
  if (isPluginMounted || !isNotebookUrl(location.href)) return;
  console.log('[NLM Cleaner] Waiting for sidebar...');

  let listContainer;
  try {
    listContainer = await waitForElement(
      () => document.querySelector(SELECTORS.SIDEBAR),
      15000
    );
  } catch (e) {
    recordFailure(
      FAILURE_TYPES.ROUTE_REMOUNT_FAIL,
      'Sidebar 在 15s 内未出现，重挂失败',
      { selector: SELECTORS.SIDEBAR }
    );
    console.warn('[NLM Cleaner] Sidebar not found within 15s — run nlmDebug()');
    window.nlmDebug?.();
    return;
  }

  isPluginMounted = true;
  scanAndInject();
  startInnerObserver(listContainer);
  console.log('[NLM Cleaner] Mounted');
}

function debouncedMount(delay = 350) {
  clearTimeout(mountDebounceTimer);
  mountDebounceTimer = setTimeout(attemptMount, delay);
}

/* ── Global Guardian (SPA route detection) ────────────────────────────── */

const globalGuardian = new MutationObserver(() => {
  const newUrl = location.href;
  if (newUrl === currentUrl) return;
  currentUrl = newUrl;
  teardown();
  if (isNotebookUrl(newUrl)) debouncedMount();
});

window.addEventListener('popstate', () => {
  const newUrl = location.href;
  if (newUrl === currentUrl) return;
  currentUrl = newUrl;
  teardown();
  if (isNotebookUrl(newUrl)) debouncedMount();
});

/* ── 事件拦截模块（防误跳转） ─────────────────────────────────────────────── */

function interceptCheckboxEvent(event) {
  const target = event.target;
  if (!(target instanceof Element)) return;
  const checkbox = target.closest('.nlm-source-checkbox');
  if (!checkbox) return;

  if (event.type in DIAG.eventInterceptions) {
    DIAG.eventInterceptions[event.type]++;
  }

  // 捕获阶段尽早阻断宿主页事件链，避免导航逻辑抢占
  event.stopPropagation();
  if (typeof event.stopImmediatePropagation === 'function') {
    event.stopImmediatePropagation();
  }

  // down 阶段阻断默认行为，避免父级/宿主页触发预导航动作
  if (event.type === 'pointerdown' || event.type === 'mousedown') {
    event.preventDefault();
  }
}

const INTERCEPT_EVENT_TYPES = ['pointerdown', 'mousedown', 'mouseup', 'click'];

function setupCheckboxInterception() {
  INTERCEPT_EVENT_TYPES.forEach((type) => {
    document.addEventListener(type, interceptCheckboxEvent, true);
  });
}

/* ── Diagnostics (window.nlmDebug) ────────────────────────────────────── */

window.nlmDebug = function () {
  console.group('[NLM Cleaner] v4 Diagnostic');
  const rootStyles = getComputedStyle(document.documentElement);
  console.log('URL:', location.href, '| notebook:', isNotebookUrl(location.href), '| mounted:', isPluginMounted);
  const sidebar = getSidebar();
  if (sidebar) {
    const items = sidebar.querySelectorAll(SELECTORS.SOURCE_ITEM);
    console.log('Sidebar:', sidebar);
    console.log('Source items:', items.length, '(' + SELECTORS.SOURCE_ITEM + ')');
    console.log('MENU_BTN:', sidebar.querySelector(SELECTORS.MENU_BTN) || 'not found \u2014 ' + SELECTORS.MENU_BTN);
    console.log('ADD_SOURCE_AREA:', sidebar.querySelector(SELECTORS.ADD_SOURCE_AREA) || 'not found \u2014 ' + SELECTORS.ADD_SOURCE_AREA);
  } else {
    console.warn('Sidebar NOT found (' + SELECTORS.SIDEBAR + ')');
    document.querySelectorAll('section').forEach((el, i) =>
      console.log('  section[' + i + ']', el.className)
    );
  }
  console.log('Theme tokens:', {
    textPrimary: rootStyles.getPropertyValue('--ext-text-primary').trim(),
    textMuted: rootStyles.getPropertyValue('--ext-text-muted').trim(),
    bgIdle: rootStyles.getPropertyValue('--ext-bg-idle').trim(),
  });
  console.log('Event interception count:', DIAG.eventInterceptions);
  console.log('Recent failures:', DIAG.failures);
  console.log('CDK overlay:', document.querySelector('.cdk-overlay-container') || 'not found');
  console.log('DELETE_MENU_ITEM (if open):', document.querySelector(SELECTORS.DELETE_MENU_ITEM) || 'not visible');
  console.groupEnd();
  return 'Done';
};

window.nlmSetDebug = function (enabled) {
  DIAG.debugEnabled = !!enabled;
  return DIAG.debugEnabled;
};

window.nlmGetFailures = function () {
  return [...DIAG.failures];
};

/* ── Init ──────────────────────────────────────────────────────────────── */

function init() {
  console.log('[NLM Cleaner] v4 \u2014 started');
  setupCheckboxInterception();
  globalGuardian.observe(document.body, { childList: true, subtree: true });
  if (isNotebookUrl(location.href)) debouncedMount(500);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
